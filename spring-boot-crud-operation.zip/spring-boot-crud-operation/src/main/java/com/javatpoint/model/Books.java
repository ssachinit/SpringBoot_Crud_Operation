package com.javatpoint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Books {

	@Id
	@Column
	private int bookid;
	@Column
	private int bookname;
	@Column
	private int bookauthor;
	@Column
	private int bookprice;
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public int getBookname() {
		return bookname;
	}
	public void setBookname(int bookname) {
		this.bookname = bookname;
	}
	public int getBookauthor() {
		return bookauthor;
	}
	public void setBookauthor(int bookauthor) {
		this.bookauthor = bookauthor;
	}
	public int getBookprice() {
		return bookprice;
	}
	public void setBookprice(int bookprice) {
		this.bookprice = bookprice;
	}
}
